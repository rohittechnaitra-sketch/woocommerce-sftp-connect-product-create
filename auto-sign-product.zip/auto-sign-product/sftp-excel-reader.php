<?php
/*
Plugin Name: SFTP WooCommerce Importer
Description: Import & Update products from SFTP Excel feeds into WooCommerce
Version: 6.1
*/

if (!defined('ABSPATH')) exit;
set_time_limit(0);
ini_set('max_execution_time', 0);
ini_set('memory_limit', '1024M');

define('SFTP_IMPORT_BATCH_SIZE', 100);
define('SFTP_IMPORT_PROGRESS_KEY', 'sftp_import_progress');

add_action('admin_menu', function () {
    add_menu_page(
        'SFTP Import Settings',
        'SFTP Import',
        'manage_options',
        'sftp-import-settings',
        'sftp_import_settings_page',
        'dashicons-database-import'
    );
});
function sftp_import_settings_page() {
    ?>
    <div class="wrap">
        <h1>SFTP Settings</h1>
         <?php settings_errors(); ?>
        <form method="post" action="options.php">
            <?php
            settings_fields('sftp_settings_group');
            do_settings_sections('sftp-import-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}
add_action('admin_init', function () {

    if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
        add_settings_error(
            'sftp_messages',
            'sftp_message',
            'SFTP settings saved successfully!',
            'updated'
        );
    }

    register_setting('sftp_settings_group', 'sftp_host');
    register_setting('sftp_settings_group', 'sftp_port');
    register_setting('sftp_settings_group', 'sftp_user');
    register_setting('sftp_settings_group', 'sftp_pass');
    register_setting('sftp_settings_group', 'sftp_path');

    add_settings_section('sftp_main_section', 'SFTP Config', null, 'sftp-import-settings');

    function sftp_input($name) {
        $value = esc_attr(get_option($name));
        echo "<input type='text' name='$name' value='$value' class='regular-text' />";
    }

    add_settings_field('sftp_host', 'Host', function(){ sftp_input('sftp_host'); }, 'sftp-import-settings', 'sftp_main_section');
    add_settings_field('sftp_port', 'Port', function(){ sftp_input('sftp_port'); }, 'sftp-import-settings', 'sftp_main_section');
    add_settings_field('sftp_user', 'Username', function(){ sftp_input('sftp_user'); }, 'sftp-import-settings', 'sftp_main_section');
    add_settings_field('sftp_pass', 'Password', function(){ sftp_input('sftp_pass'); }, 'sftp-import-settings', 'sftp_main_section');
    add_settings_field('sftp_path', 'Remote Path', function(){ sftp_input('sftp_path'); }, 'sftp-import-settings', 'sftp_main_section');
});
spl_autoload_register(function ($class) {
    $prefix   = 'phpseclib3\\';
    $base_dir = plugin_dir_path(__FILE__) . 'phpseclib/phpseclib/';
    $len      = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) return;
    $file = $base_dir . str_replace('\\', '/', substr($class, $len)) . '.php';
    if (file_exists($file)) require $file;
});

// ============================================================
// PROGRESS MANAGER
// ============================================================
function sftp_get_progress() {
    $default = [
        'offset'       => 0,       
        'total'        => 0,       // total groups/products
        'batch'        => 1,       // current batch number
        'completed'    => false,   
        'last_updated' => null,
    ];
    return get_option(SFTP_IMPORT_PROGRESS_KEY, $default);
}

function sftp_save_progress($offset, $total, $batch, $completed = false) {
    update_option(SFTP_IMPORT_PROGRESS_KEY, [
        'offset'       => $offset,
        'total'        => $total,
        'batch'        => $batch,
        'completed'    => $completed,
        'last_updated' => current_time('mysql'),
    ]);
}

function sftp_reset_progress() {
    delete_option(SFTP_IMPORT_PROGRESS_KEY);
}

// ============================================================
// XLSX PARSER
// ============================================================
function parse_xlsx_with_pclzip($filePath) {
    if (!class_exists('PclZip')) {
        require_once ABSPATH . 'wp-admin/includes/class-pclzip.php';
    }
    $zip  = new PclZip($filePath);
    $list = $zip->listContent();
    if (!$list) return [];

    $sharedStrings = [];
    foreach ($list as $entry) {
        if ($entry['filename'] === 'xl/sharedStrings.xml') {
            $data = $zip->extractByIndex($entry['index'], PCLZIP_OPT_EXTRACT_AS_STRING);
            if ($data && isset($data[0]['content'])) {
                $ssXml = simplexml_load_string($data[0]['content']);
                foreach ($ssXml->si as $si) {
                    if (isset($si->t)) {
                        $sharedStrings[] = (string)$si->t;
                    } else {
                        $text = '';
                        foreach ($si->r as $r) {
                            if (isset($r->t)) $text .= (string)$r->t;
                        }
                        $sharedStrings[] = $text;
                    }
                }
            }
            break;
        }
    }

    $sheetContent = null;

    foreach ($list as $entry) {
        if (preg_match('#xl/worksheets/sheet\d+\.xml#i', $entry['filename'])) {

            $data = $zip->extractByIndex($entry['index'], PCLZIP_OPT_EXTRACT_AS_STRING);

            if ($data && isset($data[0]['content'])) {

                $xml = simplexml_load_string($data[0]['content']);
                if (isset($xml->sheetData->row) && count($xml->sheetData->row) > 0) {
                    $sheetContent = $data[0]['content'];
                    break;
                }
            }
        }
    }
    if (!$sheetContent) return [];

    $col_to_num = function($col) {
        $num = 0;
        for ($i = 0; $i < strlen($col); $i++) {
            $num = $num * 26 + (ord($col[$i]) - ord('A') + 1);
        }
        return $num - 1;
    };

    $rows = [];
    $xml  = simplexml_load_string($sheetContent);
    foreach ($xml->sheetData->row as $row) {
        $cells  = [];
        $maxCol = 0;
        foreach ($row->c as $cell) {
            preg_match('/([A-Z]+)(\d+)/', (string)$cell['r'], $m);
            $colIdx = $col_to_num($m[1]);
            $type   = (string)$cell['t'];
            if ($type === 's') {
                $value = $sharedStrings[(int)$cell->v] ?? '';
            } elseif ($type === 'inlineStr') {
                $value = (string)$cell->is->t;
            } else {
                $value = isset($cell->v) ? (string)$cell->v : '';
            }
            $cells[$colIdx] = $value;
            $maxCol = max($maxCol, $colIdx);
        }
        $rowArr = [];
        for ($i = 0; $i <= $maxCol; $i++) {
            $rowArr[] = $cells[$i] ?? '';
        }
            if (count(array_filter($rowArr)) === 0) {
                    continue;
                }
        $rows[] = $rowArr;
    }
    return $rows;
}

function sftp_fetch_all_feeds() {
    $host = get_option('sftp_host');
    $port = get_option('sftp_port') ?: 22;
    $user = get_option('sftp_user');
    $pass = get_option('sftp_pass');
    $remote_path = get_option('sftp_path');

    $sftp = new \phpseclib3\Net\SFTP($host, $port);
    if (!$sftp->login($user, $pass)) {
            throw new \Exception('SFTP login failed');
        }
    $map = [
        'Inventory Feed' => 'inventory',
        'Item Feed'      => 'items',
        'Price Feed'     => 'prices',
    ];
    $feeds = [];
    foreach ($sftp->nlist($remote_path) as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) !== 'xlsx') continue;
        foreach ($map as $keyword => $key) {
            if (strpos($file, $keyword) !== false) {
                $tempFile = sys_get_temp_dir() . '/' . uniqid() . '_' . basename($file);
                for ($i = 1; $i <= 3; $i++) {
                    $sftp->get(rtrim($remote_path, '/') . '/' . ltrim($file, '/'), $tempFile);
                    if (file_exists($tempFile) && filesize($tempFile) > 0) break;
                    sleep(1);
                }
                if (file_exists($tempFile) && filesize($tempFile) > 0) {
                    $feeds[$key] = parse_xlsx_with_pclzip($tempFile);
                    unlink($tempFile);
                }
                break;
            }
        }
    }
    return $feeds;
}

// ============================================================
// DATA NORMALISATION
// ============================================================
function rows_to_assoc($rows) {
    if (empty($rows)) return [];
    $headers = array_shift($rows);
    $out = [];
    foreach ($rows as $row) {
        $assoc = [];
        foreach ($headers as $i => $h) {
            $assoc[trim($h)] = isset($row[$i]) ? trim($row[$i]) : '';
        }
        $out[] = $assoc;
    }
    return $out;
}

function build_price_map($priceRows) {
    $map = [];
    foreach ($priceRows as $r) {
        $itemNo = $r['Item No_'] ?? '';
        if ($itemNo === '') continue;
        $map[$itemNo] = [
            'net'         => floatval($r['Net Price'] ?? 0),
            'rrp'         => floatval($r['RRP'] ?? 0),
            'customer_no' => $r['Customer No.'] ?? '',
        ];
    }
    return $map;
}

function build_inventory_map($invRows) {
    $map = [];
    foreach ($invRows as $r) {
        $code = $r['Full Code'] ?? '';
        if ($code === '') continue;
        $map[$code] = $r;
    }
    return $map;
}

function group_items($itemRows) {
    $groups = [];
    foreach ($itemRows as $r) {
        $partNo      = $r['Part Numbers'] ?? '';
        $variantCode = $r['Variant Code'] ?? '';
        $imageUrl    = $r['URL'] ?? '';
        if ($partNo === '') continue;

        if (!isset($groups[$partNo])) {
            $groups[$partNo] = [
                'info'     => $r,
                'variants' => [],
                'images'   => [],
            ];
        }

        if ($imageUrl && !in_array($imageUrl, $groups[$partNo]['images'])) {
            $groups[$partNo]['images'][] = $imageUrl;
        }

        if ($variantCode !== '') {
            if (!isset($groups[$partNo]['variants'][$variantCode])) {
                $groups[$partNo]['variants'][$variantCode] = [
                    'data'   => $r,
                    'images' => [],
                ];
            }
            if ($imageUrl && !in_array($imageUrl, $groups[$partNo]['variants'][$variantCode]['images'])) {
                $groups[$partNo]['variants'][$variantCode]['images'][] = $imageUrl;
            }
        }
    }
    return $groups;
}

// ============================================================
// IMAGE URL CLEANER
// ============================================================
function clean_image_url($url) {
    $url = trim($url);
    if (strpos($url, '//') === 0) $url = 'https:' . $url;
    if (!preg_match('#^https?://#', $url)) $url = 'https://' . ltrim($url, '/');

    $parsed = parse_url($url);
    if (empty($parsed['host'])) return $url;

    $scheme   = $parsed['scheme'] ?? 'https';
    $host     = $parsed['host'];
    $path     = $parsed['path'] ?? '';
    $segments = explode('/', $path);
    $segments = array_map(function ($seg) {
        return rawurlencode(rawurldecode($seg));
    }, $segments);

    $result = $scheme . '://' . $host . implode('/', $segments);
    if (!empty($parsed['query'])) $result .= '?' . $parsed['query'];
    return $result;
}

function download_image_with_fallback($url) {
    $tmp = download_url($url, 60);
    if (!is_wp_error($tmp)) return $tmp;

    $decoded = urldecode($url);
    if ($decoded !== $url) {
        $tmp2 = download_url($decoded, 60);
        if (!is_wp_error($tmp2)) return $tmp2;
    }

    $plus = str_replace('%20', '+', $url);
    if ($plus !== $url) {
        $tmp3 = download_url($plus, 60);
        if (!is_wp_error($tmp3)) return $tmp3;
    }

    return $tmp;
}

// ============================================================
// TAXONOMY HELPER
// ============================================================
function assign_product_taxonomies($productId, $brand, $category) {
    if ($brand !== '') {
        foreach (['product_brand', 'pwb-brand', 'yith_product_brand'] as $brandTax) {
            if (taxonomy_exists($brandTax)) {
                $term = get_term_by('name', $brand, $brandTax);
                if (!$term) {
                    $result = wp_insert_term($brand, $brandTax);
                    $termId = is_wp_error($result) ? 0 : $result['term_id'];
                } else {
                    $termId = $term->term_id;
                }
                if ($termId) wp_set_object_terms($productId, intval($termId), $brandTax, false);
                break;
            }
        }
    }

    if ($category !== '') {
        $term = get_term_by('name', $category, 'product_cat');
        if (!$term) {
            $result = wp_insert_term($category, 'product_cat');
            $termId = is_wp_error($result) ? 0 : $result['term_id'];
        } else {
            $termId = $term->term_id;
        }
        if (!empty($termId)) wp_set_object_terms($productId, intval($termId), 'product_cat', false);
    }
}

// ============================================================
// META FIELDS HELPER Simple Prduct
// ============================================================
function save_product_meta($productId, $info, $priceData, $invData) {
    update_post_meta($productId, 'part_numbers',             $info['Part Numbers']                 ?? '');
    update_post_meta($productId, 'barcode',                  $info['Barcode']                      ?? '');
    update_post_meta($productId, 'vat_rule',                 $info['Vat Rule']                     ?? '');
    update_post_meta($productId, 'vendor_part_number_item',  $info['Vendor Part Number']            ?? '');
    update_post_meta($productId, 'vat_posting_group',        $info['VAT Prod_ Posting Group']       ?? '');
    update_post_meta($productId, 'legacy_code',              $info['Legacy Code']                   ?? '');
    update_post_meta($productId, 'country_of_origin',        $info['Country_Region of Origin Code'] ?? '');
    update_post_meta($productId, 'tariff_no',                $info['Tariff No_']                    ?? '');
    update_post_meta($productId, 'sku_colour',               $info['SKU_Colour']                    ?? '');
    update_post_meta($productId, 'colour',               $info['Colour']                    ?? '');
    update_post_meta($productId, 'size',               $info['Size']                    ?? '');
    update_post_meta($productId, 'gender',               $info['Gender']                    ?? '');
    update_post_meta($productId, 'unit_of_measure',               $info['Unit of Measure']                    ?? '');
    
    if ($priceData) {
        update_post_meta($productId, 'customer_no', $priceData['customer_no'] ?? '');
    }
    if ($invData) {
        update_post_meta($productId, 'cross_reference_no', $invData['Cross-Reference No_'] ?? '');
        update_post_meta($productId, 'vendor_part_number', $invData['Vendor Part Number']  ?? '');
        update_post_meta($productId, 'rfx_item_number',    $invData['RFX Item number']     ?? '');
    }
}

// ============================================================
// VARIABLE PRODUCT PARENT META 
// ============================================================
function save_variable_product_meta($productId, $info, $priceData) {
    update_post_meta($productId, 'part_numbers',      $info['Part Numbers']                  ?? '');
    update_post_meta($productId, 'vat_rule',          $info['Vat Rule']                      ?? '');
    update_post_meta($productId, 'vat_posting_group', $info['VAT Prod_ Posting Group']        ?? '');
    update_post_meta($productId, 'country_of_origin', $info['Country_Region of Origin Code']  ?? '');
    update_post_meta($productId, 'tariff_no',         $info['Tariff No_']                     ?? '');

    if ($priceData) {
        update_post_meta($productId, 'customer_no', $priceData['customer_no'] ?? '');
    }
}

// ============================================================
// VARIATION META — 
// ============================================================
function save_variation_meta($variationId, $varData, $invData) {
    update_post_meta($variationId, 'full_code',               $varData['Full Code']                    ?? '');
    update_post_meta($variationId, 'barcode',                 $varData['Barcode']                      ?? '');
    update_post_meta($variationId, 'vendor_part_number_item', $varData['Vendor Part Number']            ?? '');
    update_post_meta($variationId, 'legacy_code',             $varData['Legacy Code']                  ?? '');
    update_post_meta($variationId, 'sku_colour',              $varData['SKU_Colour']                   ?? '');
    update_post_meta($variationId, 'vat_rule',                $varData['Vat Rule']                     ?? '');
    update_post_meta($variationId, 'vat_posting_group',       $varData['VAT Prod_ Posting Group']      ?? '');
    update_post_meta($variationId, 'country_of_origin',       $varData['Country_Region of Origin Code'] ?? '');
    update_post_meta($variationId, 'tariff_no',               $varData['Tariff No_']                   ?? '');

    if ($invData) {
        update_post_meta($variationId, 'cross_reference_no', $invData['Cross-Reference No_'] ?? '');
        update_post_meta($variationId, 'vendor_part_number', $invData['Vendor Part Number']  ?? '');
        update_post_meta($variationId, 'rfx_item_number',    $invData['RFX Item number']     ?? '');
    }
}

// ============================================================
// ATTRIBUTE ANALYSER
// ============================================================
function analyse_attributes($variants, $fields) {
    $valueSets = array_fill_keys($fields, []);
    foreach ($variants as $variant) {
        $d = $variant['data'];
        foreach ($fields as $field) {
            $val = $d[$field] ?? '';
            if ($val !== '' && !in_array($val, $valueSets[$field])) {
                $valueSets[$field][] = $val;
            }
        }
    }
    $variationAttrs = [];
    $metaAttrs      = [];
    foreach ($valueSets as $field => $values) {
        if (count($values) > 1) {
            $variationAttrs[$field] = $values;
        } else {
            $metaAttrs[$field] = $values[0] ?? '';
        }
    }
    return ['variation' => $variationAttrs, 'meta' => $metaAttrs];
}

function get_attachment_id_by_filename($filename) {
    global $wpdb;
    $id = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id FROM {$wpdb->postmeta}
         WHERE meta_key = '_wp_attached_file'
         AND meta_value LIKE %s
         LIMIT 1",
        '%' . $wpdb->esc_like($filename)
    ));
    return $id ? (int) $id : 0;
}

function sideload_image($url, $post_id = 0, $title = '') {
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $url      = clean_image_url($url);
    $filename = sanitize_file_name(basename(parse_url($url, PHP_URL_PATH)));
    if (!$filename) $filename = 'image-' . time() . '.jpg';

    $existing = get_attachment_id_by_filename($filename);
    if ($existing) return $existing;

    $tmp = download_image_with_fallback($url);
    if (is_wp_error($tmp)) {
        error_log('SFTP Import - Image download failed: ' . $url . ' | ' . $tmp->get_error_message());
        return 0;
    }

    $id = media_handle_sideload(
        ['name' => $filename, 'tmp_name' => $tmp],
        $post_id,
        $title
    );

    if (is_wp_error($id)) {
        @unlink($tmp);
        error_log('SFTP Import - Sideload failed: ' . $id->get_error_message());
        return 0;
    }
    return $id;
}

function apply_product_images($productId, $images, $title = '') {
    if (empty($images)) return;

    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $attachIds = [];
    foreach ($images as $url) {
        $url      = clean_image_url($url);
        $filename = sanitize_file_name(basename(parse_url($url, PHP_URL_PATH)));
        if (!$filename) continue;

        $existing_id = get_attachment_id_by_filename($filename);
        if ($existing_id) {
            $attachIds[] = $existing_id;
            continue;
        }

        $tmp = download_image_with_fallback($url);
        if (is_wp_error($tmp)) {
            error_log('SFTP Import - Download failed: ' . $url . ' | ' . $tmp->get_error_message());
            continue;
        }

        $id = media_handle_sideload(
            ['name' => $filename, 'tmp_name' => $tmp],
            $productId,
            $title
        );

        if (is_wp_error($id)) {
            @unlink($tmp);
            continue;
        }
        $attachIds[] = $id;
    }

    if (empty($attachIds)) return;

    update_post_meta($productId, '_thumbnail_id', $attachIds[0]);
    if (count($attachIds) > 1) {
        update_post_meta($productId, '_product_image_gallery', implode(',', array_slice($attachIds, 1)));
    }
}

// ============================================================
// UPSERT SIMPLE PRODUCT
// ============================================================
function upsert_simple_product($partNo, $info, $images, $priceMap, $invMap) {
    $sku = $info['Full Code'] ?? $partNo;
    if (empty($sku)) $sku = $partNo;

    $priceData = $priceMap[$partNo] ?? null;
    $invData   = $invMap[$sku]     ?? null;
    $stock     = intval($invData['Availability'] ?? 0);

    $existingId = wc_get_product_id_by_sku($sku);
    $isNew      = ($existingId === 0);

    $product = $isNew ? new WC_Product_Simple() : wc_get_product($existingId);
    if (!$product) $product = new WC_Product_Simple();

    $product->set_name(sanitize_text_field($info['Product Title'] ?? ''));
    $product->set_sku($sku);

    $desc = $info['Product Website Description'] ?? '';
    $desc = str_replace('_x000a_', "\n", $desc);
    $desc = preg_replace("/(\r\n|\r|\n){2,}/", "\n\n", $desc);
    $desc = trim($desc);
    $product->set_description(wp_kses_post($desc));
    $product->set_status('publish');
    $product->set_catalog_visibility('visible');

    $weight = $info['Gross Weight'] ?? '';
    if ($weight !== '') $product->set_weight(floatval($weight));

    if ($priceData) {
        $product->set_regular_price($priceData['rrp']);
        $product->set_sale_price($priceData['net']);
    }

    $product->set_manage_stock(true);
    $product->set_stock_quantity($stock);
    $product->set_stock_status($stock > 0 ? 'instock' : 'outofstock');

    $attrs = [];
    foreach (['Colour', 'Size', 'Gender', 'Unit of Measure'] as $attr) {
        $val = $info[$attr] ?? '';
        if ($val === '') continue;
        $a = new WC_Product_Attribute();
        $a->set_name($attr);
        $a->set_options([$val]);
        $a->set_visible(true);
        $a->set_variation(false);
        $attrs[] = $a;
    }
    $product->set_attributes($attrs);

    $productId = $product->save();

    assign_product_taxonomies($productId, $info['Brand'] ?? '', $info['Category'] ?? '');
    save_product_meta($productId, $info, $priceData, $invData);
    update_post_meta($productId, '_colour',          $info['Colour']          ?? '');
    update_post_meta($productId, '_size',            $info['Size']            ?? '');
    update_post_meta($productId, '_gender',          $info['Gender']          ?? '');
    update_post_meta($productId, '_unit_of_measure', $info['Unit of Measure'] ?? '');

    apply_product_images($productId, $images, $info['Product Title'] ?? '');

    return $isNew
        ? ['created_simple' => $sku, 'id' => $productId]
        : ['updated_simple' => $sku, 'id' => $productId];
}

// ============================================================
// UDATE AND INSERT VARIABLE PRODUCT
// ============================================================
function upsert_variable_product($partNo, $info, $variants, $productImages, $priceMap, $invMap) {
    $sku       = $partNo;
    $priceData = $priceMap[$partNo] ?? null;

    $analysis       = analyse_attributes($variants, ['Colour', 'Size', 'Gender', 'Unit of Measure']);
    $variationAttrs = $analysis['variation'];
    $metaAttrs      = $analysis['meta'];

    $existingId = wc_get_product_id_by_sku($sku);
    $isNew      = ($existingId === 0);

    $product = $isNew ? new WC_Product_Variable() : wc_get_product($existingId);
    if (!$product) $product = new WC_Product_Variable();

    $product->set_name(sanitize_text_field($info['Product Title'] ?? ''));
    $product->set_sku($sku);

    $desc = $info['Product Website Description'] ?? '';
    $desc = str_replace('_x000a_', "\n", $desc);
    $desc = preg_replace("/(\r\n|\r|\n){2,}/", "\n\n", $desc);
    $desc = trim($desc);
    $product->set_description(wp_kses_post($desc));
    $product->set_status('publish');
    $product->set_catalog_visibility('visible');

    $weight = $info['Gross Weight'] ?? '';
    if ($weight !== '') $product->set_weight(floatval($weight));

    // Existing variation attributes
    $existingAttrs = [];
    if (!$isNew) {
        foreach ($product->get_attributes() as $attrKey => $attrObj) {
            if ($attrObj->get_variation()) {
                $existingAttrs[ucfirst($attrKey)] = $attrObj->get_options();
            }
        }
    }

    $attrs = [];
    foreach ($variationAttrs as $attrName => $values) {
        $merged = array_unique(array_merge($existingAttrs[$attrName] ?? [], $values));
        $a = new WC_Product_Attribute();
        $a->set_name($attrName);
        $a->set_options($merged);
        $a->set_visible(true);
        $a->set_variation(true);
        $attrs[] = $a;
    }
    $product->set_attributes($attrs);

    $productId = $product->save();

    assign_product_taxonomies($productId, $info['Brand'] ?? '', $info['Category'] ?? '');

    save_variable_product_meta($productId, $info, $priceData);
    foreach ($metaAttrs as $field => $val) {
        update_post_meta($productId, '_' . strtolower(str_replace(' ', '_', $field)), $val);
    }

    apply_product_images($productId, $productImages, $info['Product Title'] ?? '');

    $newVarCount     = 0;
    $updatedVarCount = 0;

    foreach ($variants as $variantCode => $variant) {
        $d        = $variant['data'];
        $fullCode = $d['Full Code'] ?? ($partNo . $variantCode);
        $varSku   = $fullCode ?: ($partNo . '-' . $variantCode);

        $invData = $invMap[$fullCode] ?? null;
        $stock   = intval($invData['Availability'] ?? 0);

        $existingVarId = wc_get_product_id_by_sku($varSku);
        $isNewVar      = ($existingVarId === 0);

        $variation = $isNewVar ? new WC_Product_Variation() : wc_get_product($existingVarId);
        if (!$variation) $variation = new WC_Product_Variation();

        $variation->set_parent_id($productId);
        $variation->set_sku($varSku);
        $variation->set_manage_stock(true);
        $variation->set_stock_quantity($stock);
        $variation->set_stock_status($stock > 0 ? 'instock' : 'outofstock');

        $varWeight = $d['Gross Weight'] ?? '';
        if ($varWeight !== '') $variation->set_weight(floatval($varWeight));

        if ($priceData) {
            $variation->set_regular_price($priceData['rrp']);
            $variation->set_sale_price($priceData['net']);
        }

        $varAttrs = [];
        foreach ($variationAttrs as $attrName => $values) {
            $val = $d[$attrName] ?? '';
            if ($val !== '') {
                $varAttrs['attribute_' . strtolower(str_replace(' ', '_', $attrName))] = $val;
            }
        }
        $variation->set_attributes($varAttrs);

        $varId = $variation->save();

        // Variation image
        if (!empty($variant['images'])) {
            $varImgId = sideload_image($variant['images'][0], $varId, $d['Product Title'] ?? '');
            if ($varImgId) {
                update_post_meta($varId, '_thumbnail_id', $varImgId);
            }
        }
        save_variation_meta($varId, $d, $invData);

        $isNewVar ? $newVarCount++ : $updatedVarCount++;
    }

    WC_Product_Variable::sync($productId);

    return $isNew
        ? ['created_variable' => $sku, 'id' => $productId,
           'variants_new'     => $newVarCount, 'variants_updated' => $updatedVarCount]
        : ['updated_variable' => $sku, 'id' => $productId,
           'variants_new'     => $newVarCount, 'variants_updated' => $updatedVarCount];
}

// ============================================================
// MAIN IMPORT — BATCH MODE
// ============================================================
function run_sftp_woo_import() {
    if (!function_exists('wc_get_product_id_by_sku')) {
        echo '<div style="color:red">WooCommerce not active.</div>';
        return;
    }

    $progress = sftp_get_progress();
    $offset   = (int) $progress['offset'];
    $batch    = (int) $progress['batch'];

    if ($progress['completed']) {
        $offset = 0;
        $batch  = 1;
        echo "<b style='color:blue'>Previous run was complete. Starting fresh...</b><br>";
    }
    echo "<b>Fetching feeds from SFTP (row offset: {$offset})...</b><br>";

    $feeds = sftp_fetch_all_feeds();

    $invRows   = rows_to_assoc($feeds['inventory'] ?? []);
    $itemRows  = rows_to_assoc($feeds['items']     ?? []);
    $priceRows = rows_to_assoc($feeds['prices']    ?? []);
    $priceMap = build_price_map($priceRows);
    $invMap   = build_inventory_map($invRows);
    $groups   = group_items($itemRows);

    $total = count($groups);

    if ($offset >= $total && $total > 0) {
        $offset = 0;
        $batch  = 1;
        echo "<b style='color:orange'>Offset ({$offset}) >= Total ({$total}). Resetting to start.</b><br>";
    }

    echo "Total products in Excel: <b>{$total}</b> | Resuming from row: <b>" . ($offset + 1) . "</b><br><hr>";
    $groupKeys   = array_keys($groups);
    $batchKeys   = array_slice($groupKeys, $offset, SFTP_IMPORT_BATCH_SIZE);
    $batchGroups = array_intersect_key($groups, array_flip($batchKeys));

    echo "Processing batch <b>{$batch}</b>: rows <b>" . ($offset + 1) . "</b> to <b>" . min($offset + SFTP_IMPORT_BATCH_SIZE, $total) . "</b> of <b>{$total}</b><br><hr>";

    $stats = [
        'created_simple'   => 0,
        'updated_simple'   => 0,
        'created_variable' => 0,
        'updated_variable' => 0,
        'errors'           => 0,
    ];

foreach ($batchGroups as $partNo => $group) {
    try {
        $info     = $group['info'];
        $variants = $group['variants'];
        $images   = $group['images'];
        if (empty($variants)) {
            $result = upsert_simple_product($partNo, $info, $images, $priceMap, $invMap);
        } elseif (count($variants) === 1) {
            $onlyVariant  = reset($variants);
            $mergedInfo   = array_merge($info, $onlyVariant['data']);
            $mergedImages = !empty($onlyVariant['images']) ? $onlyVariant['images'] : $images;

            $result = upsert_simple_product($partNo, $mergedInfo, $mergedImages, $priceMap, $invMap);
        } else {
            $result = upsert_variable_product($partNo, $info, $variants, $images, $priceMap, $invMap);
        }

        if (isset($result['created_simple'])) {
            $stats['created_simple']++;
            echo "Created simple: <b>{$result['created_simple']}</b> (ID: {$result['id']})<br>";
        } elseif (isset($result['updated_simple'])) {
            $stats['updated_simple']++;
            echo "Updated simple: <b>{$result['updated_simple']}</b> (ID: {$result['id']})<br>";
        } elseif (isset($result['created_variable'])) {
            $stats['created_variable']++;
            echo "Created variable: <b>{$result['created_variable']}</b> (ID: {$result['id']}) — {$result['variants_new']} new variants<br>";
        } elseif (isset($result['updated_variable'])) {
            $stats['updated_variable']++;
            echo "Updated variable: <b>{$result['updated_variable']}</b> (ID: {$result['id']}) — {$result['variants_new']} new, {$result['variants_updated']} updated variants<br>";
        }

    } catch (\Throwable $e) {
        $stats['errors']++;
        echo "Error on <b>$partNo</b>: " . $e->getMessage() . "<br>";
    }
}

    $newOffset = $offset + count($batchGroups);

    if ($newOffset >= $total) {
        sftp_save_progress(0, $total, 1, true);

       echo "<hr><b style='color:green'>✅ All {$total} rows processed! The offset has been reset in the database. The next run will start fresh.</b><br>";
    } else {
        sftp_save_progress($newOffset, $total, $batch + 1, false);
        $remaining = $total - $newOffset;
        echo "<hr><b style='color:orange'>⏸ Batch {$batch} done.</b> "
        . "Saved row in DB: <b>{$newOffset}</b> / {$total}. "
        . "<b>{$remaining}</b> rows remaining.<br>";
        echo "<b>Next run will start from row <b>" . ($newOffset + 1) . "</b>.</b><br>";
    }

    echo "<hr>";
    echo "Simple created: {$stats['created_simple']}<br>";
    echo "Simple updated: {$stats['updated_simple']}<br>";
    echo "Variable created: {$stats['created_variable']}<br>";
    echo "Variable updated: {$stats['updated_variable']}<br>";
    echo "Errors: {$stats['errors']}<br>";
}
add_action('woocommerce_display_product_attributes', function() {
    global $product;

    if (!$product) return;

    $product_id = $product->get_id();

    // Get all meta
    $meta_data = get_post_meta($product_id);

    if (empty($meta_data)) return;

    echo '<div class="custom-meta-wrapper">';
    echo '<h3>Additional Information</h3>';
    echo '<table class="shop_attributes">';

    foreach ($meta_data as $key => $values) {

        // Skip unwanted system/meta keys
        if (
            strpos($key, '_') === 0 || // skip hidden (_ fields)
            in_array($key, ['_edit_lock','_edit_last'])
        ) {
            continue;
        }

        $value = implode(', ', $values);

        if (!empty($value)) {
            echo '<tr>';
            echo '<th>' . esc_html(ucwords(str_replace('_',' ', $key))) . '</th>';
            echo '<td>' . esc_html($value) . '</td>';
            echo '</tr>';
        }
    }

    echo '</table>';
    echo '</div>';

}, 35);

// ============================================================
// VARIATION DATA FRONTEND
// ============================================================
add_filter('woocommerce_available_variation', function($data, $product, $variation) {
    $data['barcode']                 = get_post_meta($variation->get_id(), 'barcode',                 true);
    $data['full_code']               = get_post_meta($variation->get_id(), 'full_code',               true);
    $data['legacy_code']             = get_post_meta($variation->get_id(), 'legacy_code',             true);
    $data['sku_colour']              = get_post_meta($variation->get_id(), 'sku_colour',              true);
    $data['vendor_part_number_item'] = get_post_meta($variation->get_id(), 'vendor_part_number_item', true);
    $data['cross_reference_no']      = get_post_meta($variation->get_id(), 'cross_reference_no',      true);
    return $data;
}, 10, 3);

// ============================================================
// HTML PLACEHOLDER + JS
// ============================================================
add_action('woocommerce_single_product_summary', function() {
    global $product;
    if (!$product->is_type('variable')) return;

    // ✅ Labels define karo — JS mein use hoga
    $fields = [
        'barcode'                 => 'Barcode',
        'full_code'               => 'Full Code',
        'legacy_code'             => 'Legacy Code',
        'sku_colour'              => 'SKU Colour',
        'vendor_part_number_item' => 'Vendor Part No.',
        'cross_reference_no'      => 'Cross Reference No.',
    ];
    ?>
    <div class="variation-meta-details" style="display:none; margin:15px 0; padding:12px; border:1px solid #ddd;">
        <table class="variation-meta-table" style="width:100%;">
            <tbody id="variation-meta-tbody">
                <!-- ✅ JS dynamically rows fill karega — empty rows nahi aayengi -->
            </tbody>
        </table>
    </div>

    <script>
    jQuery(document).ready(function($) {

        // ✅ Field labels map
        var fieldLabels = <?= json_encode($fields) ?>;

        function clean(val) {
            if (val === null || val === undefined) return '';
            val = val.toString().trim();
            if (val === '—' || val === '-') return '';
            return val;
        }

        $('form.variations_form').on('found_variation', function(e, variation) {
            var tbody = $('#variation-meta-tbody');
            tbody.empty(); // Pehle clear karo

            var hasData = false;

            // ✅ Sirf non-empty values ki rows banao
            $.each(fieldLabels, function(key, label) {
                var val = clean(variation[key]);
                if (val === '') return; // ✅ Empty — row skip karo

                tbody.append(
                    '<tr>' +
                        '<th style="width:40%; padding:4px 8px; text-align:left;">' + label + '</th>' +
                        '<td style="padding:4px 8px;">' + $('<span>').text(val).html() + '</td>' +
                    '</tr>'
                );
                hasData = true;
            });

            // ✅ Koi bhi value hai toh show karo
            if (hasData) {
                $('.variation-meta-details').slideDown(200);
            } else {
                $('.variation-meta-details').hide();
            }
        });

        // ✅ Reset hone pe hide karo
        $('form.variations_form').on('reset_data', function() {
            $('.variation-meta-details').hide();
            $('#variation-meta-tbody').empty();
        });

    });
    </script>
    <?php
}, 25);

add_filter('cron_schedules', function ($schedules) {
    $schedules['every_5_minutes'] = [
        'interval' => 300,
        'display'  => 'Every 5 Minutes'
    ];
    return $schedules;
});
add_action('wp', function () {
    if (!wp_next_scheduled('sftp_import_cron')) {
        wp_schedule_event(time(), 'every_5_minutes', 'sftp_import_cron');
    }
});
add_action('sftp_import_cron', 'run_sftp_import_cron');

function run_sftp_import_cron() {
    try {
        run_sftp_woo_import();
        error_log('IMPORT RUN OK');
    } catch (\Throwable $e) {
        error_log('IMPORT ERROR: ' . $e->getMessage());
    }
}